# LogiForm

- HTML,
- SCSS,
- Gulp,
- JS


Install dependencies:
```
npm i
```

Run in development mode:
```
gulp default
```

Compile a version for publication:
```
gulp docs
```